package com.kgz.mobile.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FishingMinigame(
    progress: Float, // 0.0f - 1.0f (положение рыбы)
    zoneStart: Float, // Начало зеленой зоны
    zoneEnd: Float,
    onPullClick: () -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .background(Color(0xFF1E1E24), RoundedCornerShape(16.dp))
                .padding(24.dp)
                .width(300.dp)
        ) {
            Text("Рыбалка: Удерживай шкалу!", color = Color.White, fontSize = 18.sp)
            Spacer(modifier = Modifier.height(20.dp))

            // Шкала прогресса рыбалки
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .background(Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            ) {
                // Зеленая зона успешного улова
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(zoneEnd - zoneStart)
                        .padding(start = (zoneStart * 300).dp)
                        .background(Color(0xFF00FF66).copy(alpha = 0.5f))
                )
                // Ползунок рыбы
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(6.dp)
                        .padding(start = (progress * 300).dp)
                        .background(Color.White, RoundedCornerShape(3.dp))
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onPullClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FFFF))
                ) {
                    Text("ТЯНУТЬ", color = Color.Black)
                }
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("ВЫЙТИ")
                }
            }
        }
    }
}
