package com.kgz.mobile.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class LootItem(val id: Int, val name: String, val type: String)

@Composable
fun LootStorageUi(
    itemsList: List<LootItem>,
    onActivateItem: (LootItem) -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f))
            .padding(40.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .fillMaxHeight(0.8f)
                .background(Color(0xFF15151A), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFBD00FF), RoundedCornerShape(12.dp)) // Неоновая фиолетовая рамка
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ВАША ДОБЫЧА (ВРЕМЕННЫЙ СКЛАД)", color = Color.White, fontSize = 22.sp)
                Button(onClick = onClose, colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)) {
                    Text("X", color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Сетка предметов в добыче
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(itemsList) { item ->
                    Column(
                        modifier = Modifier
                            .background(Color(0xFF22222B), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(item.name, color = Color.White, fontSize = 14.sp)
                        Text(item.type, color = Color.Gray, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { onActivateItem(item) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF))
                        ) {
                            Text("Забрать", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}