#include "KgzClient.h"
#include <android/log.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "KGZ_NETWORK", __VA_ARGS__)

KgzClient::KgzClient() : serverPort(0), isRunning(false), rakPeer(nullptr) {
    // В реальной сборке здесь инициализируется RakPeerInterface::GetInstance()
}

KgzClient::~KgzClient() {
    isRunning = false;
}

void KgzClient::SetupConnection(const std::string& ip, int port) {
    serverIP = ip;
    serverPort = port;
    isRunning = true;
    
    LOGI("Connecting to target server %s:%d", serverIP.c_str(), serverPort);
    // Логика запуска потока сети и вызова RakPeer->Connect
}

void KgzClient::Pulse() {
    if (!isRunning) return;
    // Постоянный опрос входящих пакетов (Packet* packet = rakPeer->Receive())
}

void KgzClient::SendPacket(unsigned char packetID, const char* data, int length) {
    if (!isRunning) return;
    // Логика упаковки в BitStream и отправки через rakPeer->Send
}

