#include <sys/mman.h>
#include <unistd.h>
#include <stdint.h>

class MemoryPatcher {
public:
    static bool Unprotect(uintptr_t address, size_t size) {
        size_t pageSize = sysconf(_SC_PAGESIZE);
        uintptr_t pageStart = address & ~(pageSize - 1);
        return mprotect((void*)pageStart, size + (address - pageStart), PROT_READ | PROT_WRITE | PROT_EXEC) == 0;
    }

    static void WriteMemory(uintptr_t address, void* value, size_t size) {
        if (Unprotect(address, size)) {
            __builtin_memcpy((void*)address, value, size);
            // Очистка кэша инструкций процессора после патча памяти
            __builtin___clear_cache((char*)address, (char*)(address + size));
        }
    }

    static void ApplyMobilePatches() {
        // Пример патча: Отключение стандартного лимита кадров оригинальной игры
        uint8_t nopOpcode[4] = {0x00, 0xF0, 0x20, 0xE3}; // NOP для ARM
        // WriteMemory(0x123456, &nopOpcode, 4); // Адрес указан для примера
    }
};

