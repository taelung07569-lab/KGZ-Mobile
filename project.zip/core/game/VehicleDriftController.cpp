#include <stdint.h>
#include <cmath>

class VehicleDriftController {
private:
    float m_fCurrentSlideAngle;
    bool m_bIsDrifting;

public:
    VehicleDriftController() : m_fCurrentSlideAngle(0.0f), m_bIsDrifting(false) {}

    // Метод сглаживания угла скольжения перед отправкой в InCarSyncData
    void ProcessDriftPhysics(uint32_t vehiclePtr, float velocityX, float velocityY) {
        if (!vehiclePtr) return;

        // Расчет вектора направления движения авто относительно его скорости
        float speed = std::sqrt(velocityX * velocityX + velocityY * velocityY);
        if (speed < 5.0f) { // Слишком низкая скорость для дрифта
            m_bIsDrifting = false;
            m_fCurrentSlideAngle = 0.0f;
            return;
        }

        // Извлечение угла направления авто из структуры RenderWare матрицы
        float* matrix = (float*)(vehiclePtr + 0x14); // Смещение матрицы авто
        float dirX = matrix[4]; 
        float dirY = matrix[5];

        // Скалярное произведение для вычисления угла заноса
        float dot = (velocityX * dirX + velocityY * dirY) / speed;
        if (dot < 0.96f) { // Угол заноса превышает порог стабильности
            m_bIsDrifting = true;
            m_fCurrentSlideAngle = std::acos(dot) * (180.0f / 3.14159265f);
        } else {
            m_bIsDrifting = false;
        }
    }

    float GetSlideAngle() const { return m_fCurrentSlideAngle; }
    bool IsDrifting() const { return m_bIsDrifting; }
};

